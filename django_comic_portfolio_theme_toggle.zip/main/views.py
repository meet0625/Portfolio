
from django.shortcuts import render
def home(r): return render(r,'main/home.html')
def about(r): return render(r,'main/about.html')
def skills(r): return render(r,'main/skills.html')
def education(r): return render(r,'main/education.html')
def work(r): return render(r,'main/work.html')
def contact(r): return render(r,'main/contact.html')
