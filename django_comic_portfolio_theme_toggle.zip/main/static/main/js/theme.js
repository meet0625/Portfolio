
function toggleTheme(){
 const body=document.body;
 const btn=document.querySelector('.theme-btn');
 if(body.getAttribute('data-theme')==='dark'){
  body.removeAttribute('data-theme');
  btn.textContent='🌙';
  localStorage.setItem('theme','light');
 }else{
  body.setAttribute('data-theme','dark');
  btn.textContent='☀️';
  localStorage.setItem('theme','dark');
 }
}

window.onload=()=>{
 const theme=localStorage.getItem('theme');
 if(theme==='dark'){
  document.body.setAttribute('data-theme','dark');
  document.querySelector('.theme-btn').textContent='☀️';
 }
}
